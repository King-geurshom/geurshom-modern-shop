GEURSHOM MODERN SHOP — BYOSE 3 (WEBSITE + ADMIN + MOMO)

IBIRIMO
- public/index.html: urubuga rw'abakiriya
- public/admin.html: dashboard yo kongeramo/guhindura/gusiba ibicuruzwa
- server.js: backend na endpoints
- .env.example: aho ushyira admin login n'amakuru ya MTN MoMo
- package.json: dependencies na command yo gutangiza server

GUKORESHA KURI PC
1. Install Node.js LTS kuri mudasobwa (nodejs.org).
2. Extract All kuri ZIP.
3. Fungura folder muri VS Code cyangwa Terminal/Command Prompt.
4. Kora copy ya .env.example uyite .env.
5. Hindura ADMIN_USERNAME, ADMIN_PASSWORD na SESSION_SECRET muri .env.
6. Fungura terminal muri folder, ukore: npm install
7. Tangiza: npm start
8. Fungura http://localhost:3000
9. Admin: http://localhost:3000/admin.html

MOMO
- Ukeneye MTN MoMo developer account n'API credentials za Collection.
- Shyira MOMO_SUBSCRIPTION_KEY, MOMO_API_USER, MOMO_API_KEY muri .env.
- Ubu code ikoresha sandbox default. Currency ya requesttopay ishyizwe kuri EUR muri sample API call; mbere yo gukoresha amafaranga nyayo, ugomba kugenzura currency/market settings za MTN MoMo account ya Rwanda n'ibisabwa na MTN, hanyuma ukayihindura uko MTN ibiteganya. Ntugashyire API keys muri public HTML.
- Tangira ukoresheje sandbox. Ntukabone ko ubwishyu bwemejwe utabanje kugenzura payment status endpoint/callback; iyi package yohereza request gusa kandi ikakira response yo kohereza request.
- Production payment requires production credentials, HTTPS callback, payment status verification, and testing with MTN.

KUBYEREKANA KURI INTERNET
- Iyi ni Node.js app; uyishyire kuri hosting yemera Node.js (urugero Render cyangwa VPS), si static hosting yonyine.
- Shyira environment variables za .env mu dashboard ya hosting, ntuzohereze .env kuri GitHub.
- Kuri production, koresha database ihoraho (PostgreSQL/MongoDB) aho kwishingikiriza kuri data/products.json, kuko filesystem ya hosting zimwe zisibwa igihe app yongeye gutangizwa.
- Kugira ngo ngufashe kuyishyira live, uzakenera konti ya hosting/domain no kongeramo MoMo API credentials zawe. Ntunyohereze password cyangwa API secret muri chat.

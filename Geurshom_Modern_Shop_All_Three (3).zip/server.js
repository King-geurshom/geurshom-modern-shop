require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const axios = require("axios");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const PRODUCTS_FILE = path.join(DATA_DIR, "products.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(PRODUCTS_FILE)) {
  fs.writeFileSync(PRODUCTS_FILE, JSON.stringify([
    {id:1,name:"Bluetooth Speaker",price:18000,category:"Ibikoresho by’amajwi",emoji:"🔊"},
    {id:2,name:"Smart Watch",price:20000,category:"Smart Watch",emoji:"⌚"},
    {id:3,name:"Power Bank 20000mAh",price:15000,category:"Electronics",emoji:"🔋"},
    {id:4,name:"Imikufi y’amasaro",price:8000,category:"Imikufi",emoji:"📿"}
  ], null, 2));
}
const readProducts = () => JSON.parse(fs.readFileSync(PRODUCTS_FILE, "utf8"));
const writeProducts = p => fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(p, null, 2));

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV === "production", maxAge: 8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,"public")));

function adminOnly(req,res,next){
  if(req.session && req.session.isAdmin) return next();
  return res.status(401).json({error:"Ugomba kubanza kwinjira nka admin."});
}
app.get("/api/products",(req,res)=>res.json(readProducts()));
app.post("/api/admin/login", async (req,res)=>{
  const {username,password}=req.body||{};
  const expectedUser=process.env.ADMIN_USERNAME || "admin";
  const expectedPass=process.env.ADMIN_PASSWORD || "ChangeThisPassword123!";
  const okUser=String(username||"")===expectedUser;
  const okPass=await bcrypt.compare(String(password||""), await bcrypt.hash(expectedPass, 10));
  if(!okUser || !okPass) return res.status(401).json({error:"Izina cyangwa ijambo ry'ibanga si byo."});
  req.session.isAdmin=true;
  res.json({ok:true});
});
app.post("/api/admin/logout",adminOnly,(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/admin/me",(req,res)=>res.json({isAdmin:!!(req.session&&req.session.isAdmin)}));

app.post("/api/admin/products",adminOnly,(req,res)=>{
  const {name,price,category,emoji,image}=req.body||{};
  if(!name || !Number.isFinite(Number(price)) || Number(price)<0 || !category)
    return res.status(400).json({error:"Uzuza izina, igiciro n'icyiciro."});
  const items=readProducts();
  const item={id:Date.now(),name:String(name).trim(),price:Number(price),category:String(category),emoji:String(emoji||"🛍️"),image:String(image||"")};
  items.unshift(item); writeProducts(items); res.status(201).json(item);
});
app.put("/api/admin/products/:id",adminOnly,(req,res)=>{
  const items=readProducts(), id=Number(req.params.id), idx=items.findIndex(p=>p.id===id);
  if(idx<0) return res.status(404).json({error:"Igicuruzwa nticyabonetse."});
  const {name,price,category,emoji,image}=req.body||{};
  if(!name || !Number.isFinite(Number(price)) || Number(price)<0 || !category)
    return res.status(400).json({error:"Uzuza izina, igiciro n'icyiciro."});
  items[idx]={...items[idx],name:String(name).trim(),price:Number(price),category:String(category),emoji:String(emoji||"🛍️"),image:String(image||"")};
  writeProducts(items); res.json(items[idx]);
});
app.delete("/api/admin/products/:id",adminOnly,(req,res)=>{
  const items=readProducts(), next=items.filter(p=>p.id!==Number(req.params.id));
  if(next.length===items.length) return res.status(404).json({error:"Igicuruzwa nticyabonetse."});
  writeProducts(next); res.json({ok:true});
});

// MTN MoMo Collection API scaffold. Use sandbox credentials for testing first.
async function momoToken(){
  const key=process.env.MOMO_SUBSCRIPTION_KEY, user=process.env.MOMO_API_USER, apiKey=process.env.MOMO_API_KEY;
  if(!key||!user||!apiKey) throw new Error("MTN MoMo API credentials ntizashyizwemo muri .env.");
  const auth=Buffer.from(`${user}:${apiKey}`).toString("base64");
  const base=(process.env.MOMO_BASE_URL||"https://sandbox.momodeveloper.mtn.com").replace(/\/$/,"");
  const r=await axios.post(`${base}/collection/token/`,null,{
    headers:{Authorization:`Basic ${auth}`,"Ocp-Apim-Subscription-Key":key}
  });
  return {token:r.data.access_token,base,key};
}
app.post("/api/pay/momo",async(req,res)=>{
  try{
    const {productId,phone}=req.body||{};
    const p=readProducts().find(x=>x.id===Number(productId));
    if(!p) return res.status(404).json({error:"Igicuruzwa nticyabonetse."});
    const normalized=String(phone||"").replace(/[^\d]/g,"");
    if(!/^2507\d{8}$/.test(normalized)) return res.status(400).json({error:"Andika nimero ya MTN Rwanda mu buryo bwa 2507XXXXXXXX."});
    const {token,base,key}=await momoToken();
    const reference=crypto.randomUUID();
    await axios.post(`${base}/collection/v1_0/requesttopay`,{
      amount:String(p.price),currency:"EUR",externalId:String(p.id),
      payer:{partyIdType:"MSISDN",partyId:normalized},
      payerMessage:`Geurshom Shop: ${p.name}`.slice(0,140),
      payeeNote:`Order ${reference}`.slice(0,140)
    },{
      headers:{
        Authorization:`Bearer ${token}`,
        "X-Reference-Id":reference,
        "X-Target-Environment":process.env.MOMO_TARGET_ENVIRONMENT||"sandbox",
        "Ocp-Apim-Subscription-Key":key,
        "Content-Type":"application/json",
        "X-Callback-Url": process.env.MOMO_CALLBACK_URL || undefined
      }
    });
    res.json({ok:true,reference,message:"Icyifuzo cyo kwishyura cyoherejwe. Reba kuri telefoni yawe wemeze ubwishyu."});
  }catch(e){
    const detail=e.response?.data?.message || e.response?.data?.error || e.message;
    res.status(502).json({error:`MoMo ntiyashoboye gutunganya ubwishyu: ${detail}`});
  }
});
app.get("/api/health",(req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log(`Geurshom Modern Shop running on port ${PORT}`));
